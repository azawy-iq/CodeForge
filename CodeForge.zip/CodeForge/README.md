# CodeForge — محرر أكواد Swift من آيفونك + بناء تلقائي لملف .ipa

تطبيق بسيط يخليك تكتب مشروع Swift كامل (عدة ملفات) من آيفونك، وترفعه GitHub،
وتخلي GitHub تبني لك ملف `.ipa` تلقائياً على سيرفرات ماك حقيقية — بدون ما تحتاج
جهاز ماك عندك.

---

## الجزء 1: رفع المشروع من آيفونك مباشرة (بدون فتح Xcode أبداً)

هذا المشروع فيه ملف `project.yml` — أداة اسمها **XcodeGen** تقرأه وتولّد ملف
مشروع Xcode تلقائياً بالسحابة (عبر GitHub Actions). يعني ما راح تحتاج تفتح
Xcode ولا مرة وحدة.

### خطوات الرفع من متصفح آيفونك (Safari):

1. روح لـ **github.com** وسجّل حساب لو ما عندك.
2. اضغط **+** أعلى الصفحة > **New repository**.
   - الاسم: `CodeForge`
   - اختر **Public** أو **Private**
   - اضغط **Create repository**.
3. بالصفحة اللي تفتح، اضغط رابط **uploading an existing file**.
4. اضغط **choose your files** وارفع الملفات **دفعة وحدة** (تقدر تحدد كذا ملف
   مرة وحدة من تطبيق الملفات على آيفونك):
   - `project.yml`
   - `README.md`
5. اكتب رسالة بسيطة بالأسفل مثل "أول رفعة" واضغط **Commit changes**.

### لإنشاء المجلدات الفرعية (CodeForge/Editor إلخ) من آيفونك:

الرفع المباشر لا يحافظ على هيكلة المجلدات بسهولة من الجوال، فالطريقة الأسهل
لكل ملف كود:

1. من صفحة المستودع، اضغط **Add file** > **Create new file**.
2. بمربع اسم الملف، اكتب **المسار كامل** مباشرة، مثلاً:
   ```
   CodeForge/CodeForgeApp.swift
   ```
   (GitHub يفهم `/` وينشئ المجلد `CodeForge` تلقائياً)
3. الصق محتوى الملف بالمربع الكبير (انسخه من الملف اللي أرسلته لك).
4. اضغط **Commit changes**.
5. كرر نفس الخطوات لباقي الملفات بهذي المسارات بالضبط:
   ```
   CodeForge/ProjectListView.swift
   CodeForge/Editor/CodeEditorView.swift
   CodeForge/Editor/SyntaxHighlighter.swift
   CodeForge/FileSystem/ProjectFileManager.swift
   .github/workflows/build-ipa.yml
   ```

### لرفع صورة الأيقونة (ملفات PNG لا تُنشأ كـ "نص"):

1. روح داخل المستودع للمسار (أنشئه بنفس طريقة "Create new file" أعلاه، بس
   حط بالنهاية اسم ملف مؤقت ثم احذفه بعدين، أو استخدم الطريقة الأسهل):
2. من الصفحة الرئيسية للمستودع اضغط **Add file** > **Upload files**.
3. افتح مسار `CodeForge/Assets.xcassets/AppIcon.appiconset/` بالضغط على
   المجلدات لو موجودة، أو اسحب الصورة وGitHub بيسألك commit مباشرة على نفس
   المسار لو كنت بداخل المجلد.
4. ارفع `AppIcon-1024.png` و `Contents.json` (الملفين اللي أرسلتهم لك) داخل
   هذا المسار بالضبط.
5. لا تنسَ ملف `Contents.json` الثاني (الأعم) في مسار
   `CodeForge/Assets.xcassets/Contents.json` — موجود لك جاهز بالمشروع
   المرفق أيضاً.

>💡 **نصيحة توفر عليك وقت:** لو الأمر صار معقد بالرفع ملف-ملف، حمّل تطبيق
> **Working Copy** (مجاني) من App Store — يخليك تفتح المشروع كامل كمجلد
> واحد وترفعه لـ GitHub بضغطة وحدة، مع الحفاظ على كل المجلدات الفرعية
> تلقائياً.

### كيف تستخدمه:
- اضغط **+** لإنشاء ملف Swift جديد.
- اضغط على أي ملف لفتح المحرر.
- اكتب كودك — يُحفظ تلقائياً مع كل تعديل.
- زر العين 👁 يعرض الكود ملوّناً (تلوين بسيط للكلمات المفتاحية والتعليقات).
- الملفات تُخزَّن داخل `Documents` الخاصة بالتطبيق، وتقدر توصلها عبر تطبيق **الملفات**
  (Files app > On My iPhone > CodeForge) لنسخها أو مشاركتها.

---

## الجزء 2: رفع المشروع على GitHub

1. حمّل تطبيق **GitHub** أو **Working Copy** من App Store (يدعمان إدارة Git من آيفون).
2. أنشئ مستودع (Repository) جديد باسم `CodeForge` من حسابك في GitHub.
3. ارفع مجلد المشروع كامل (بما فيه مجلد `.github/workflows` المرفق هنا) إلى المستودع.

**بديل أسهل من الكمبيوتر:** لو عندك وصول لأي كمبيوتر ولو مؤقتاً، أسهل طريقة:
```bash
git init
git add .
git commit -m "أول نسخة من CodeForge"
git branch -M main
git remote add origin https://github.com/USERNAME/CodeForge.git
git push -u origin main
```

---

## الجزء 3: بناء ملف .ipa تلقائياً عبر GitHub Actions

ملف `.github/workflows/build-ipa.yml` المرفق يخلي GitHub تبني مشروعك تلقائياً
على جهاز ماك حقيقي (توفره GitHub مجاناً بحد شهري محدود) في كل مرة ترفع تحديث.

### لتفعيل بناء .ipa فعلي قابل للتثبيت (وليس فقط تجربة أن الكود يترجم):

1. **احصل على حساب Apple Developer** ($99/سنة) من developer.apple.com.
2. **صدّر شهادة التوقيع (Signing Certificate)** و **Provisioning Profile** من حسابك.
3. أضفهم كـ "Secrets" في مستودع GitHub:
   - `Settings` > `Secrets and variables` > `Actions` > `New repository secret`
4. افتح ملف `build-ipa.yml` واحذف السطر `if: false` من خطوتي
   `Archive & Export IPA` و `Upload IPA as artifact`.
5. أنشئ ملف `ExportOptions.plist` بجانب مشروعك (يحدد نوع التوزيع: `development`
   أو `ad-hoc`).
6. بعد أي `git push`، روح لتبويب **Actions** بالمستودع، وبعد دقائق راح تلقى
   ملف `.ipa` جاهز للتحميل من قسم **Artifacts**.

### تثبيت الـ .ipa الناتج على آيفونك:
استخدم **AltStore** أو **SideStore** (مجانية) لتثبيت ملف `.ipa` مباشرة على جهازك
بدون App Store.

---

## حدود هذه الأداة (بصراحة تامة)

- هذا محرر نصوص/أكواد بسيط، **مو Xcode كامل** — ما فيه IntelliSense، ولا Debugger
  حقيقي، ولا محاكي مدمج.
- أي مشروع يستخدم مكتبات خارجية (CocoaPods/SPM) أو ملفات موارد (صور، فيديو) يحتاج
  تعديل يدوي إضافي على مستوى GitHub Actions.
- خطوة التوقيع (Signing) هي الأصعب تقنياً وتحتاج صبر أول مرة تعدّها — بعدها تصير
  تلقائية بالكامل.

هذي أداة بداية جيدة لتنظيم وكتابة كود من جوالك، والبناء الفعلي يتم عبر خوادم
GitHub القوية — نفس الفكرة اللي تستخدمها شركات كبيرة لأتمتة نشر تطبيقاتها.
